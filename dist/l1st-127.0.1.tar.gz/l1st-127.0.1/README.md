# 1-indexed-List-in-Python
Does exactly what it says on the tin!
